#include "board.h"

void GY53_Init(void);
extern int distance[3];
