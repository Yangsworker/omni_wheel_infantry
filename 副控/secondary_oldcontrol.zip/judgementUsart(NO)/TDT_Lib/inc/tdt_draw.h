#ifndef __TDT_DRAW_H
#define __TDT_DRAW_H


void draw_schedule1(void);
void draw_schedule2(void);//No Use
void send_schedule1(void);
void recv_COM_schedule(void);

#endif
